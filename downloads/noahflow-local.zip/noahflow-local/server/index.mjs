import { createApp } from "./app.mjs";

const port = Number(process.env.PORT || 3001);
const host = process.env.HOST || "127.0.0.1";
const app = createApp();
app.server.listen(port, host, () => {
  console.log(
    `Noahbrain demo API listening on ${host}:${port}. No external messages are sent.`,
  );
});

for (const signal of ["SIGINT", "SIGTERM"])
  process.once(signal, async () => {
    await app.close();
    process.exit(0);
  });
