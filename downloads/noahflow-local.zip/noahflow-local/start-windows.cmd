@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
where node >nul 2>&1
if errorlevel 1 (
  echo Node.js 24 or later is required.
  echo Install Node.js from https://nodejs.org/ and run this file again.
  echo.
  pause
  exit /b 1
)
node "%~dp0scripts\start-local.mjs"
if errorlevel 1 (
  echo.
  echo Please check the error above. See START-HERE.txt for instructions.
  pause
)
endlocal
