#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
if ! command -v node >/dev/null 2>&1; then
  echo 'Node.js 24 or later is required. Install it from https://nodejs.org/'
  exit 1
fi
exec node scripts/start-local.mjs
